public class AccessDemo {

    public String publicData = "Public data";

    private String privateData = "Private data";

    protected String protectedData = "Protected data";

    public void displayInsideClass() {

        System.out.println("Inside class:");

        System.out.println(publicData);
        System.out.println(privateData);
        System.out.println(protectedData);
    }

    public String getPrivateData() {

        return privateData;
    }
}