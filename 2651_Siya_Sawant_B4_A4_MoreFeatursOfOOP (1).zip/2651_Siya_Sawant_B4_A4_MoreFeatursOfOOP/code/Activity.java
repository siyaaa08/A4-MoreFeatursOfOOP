import java.io.Serializable;

public class Activity implements Serializable {

    private String name;
    private String description;
    private ActivityType type;
    private int year;

    public Activity(String name, String description,
                    ActivityType type, int year) {

        this.name = name;
        this.description = description;
        this.type = type;
        this.year = year;
    }

    public void display() {

        System.out.println(
                name + " - " + description +
                " [" + type + ", " + year + "]");
    }

    public String getName() {
        return name;
    }

    public ActivityType getType() {
        return type;
    }
}