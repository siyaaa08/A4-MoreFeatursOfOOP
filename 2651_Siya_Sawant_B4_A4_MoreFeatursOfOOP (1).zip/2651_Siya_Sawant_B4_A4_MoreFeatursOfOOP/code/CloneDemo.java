public class CloneDemo {

    public static void run(Student original) {

        System.out.println("\n===== CLONING =====");

        // Shallow clone
        Student shallow =
                (Student) original.clone();

        System.out.println("Shallow clone created.");

        shallow.address.city = "Mumbai";

        System.out.println(
                "Original address after shallow clone change: "
                        + original.address.city);

        // Deep clone
        Student deep =
                original.deepClone();

        System.out.println("Deep clone created.");

        deep.address.city = "Pune";

        System.out.println(
                "Original address after deep clone change: "
                        + original.address.city);

        System.out.println(
                "Deep clone address: "
                        + deep.address.city);
    }
}