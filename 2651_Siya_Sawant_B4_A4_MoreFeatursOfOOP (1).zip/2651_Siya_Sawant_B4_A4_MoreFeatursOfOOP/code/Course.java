import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Course implements Serializable {

    private String courseName;
    private ProgramType program;
    private List<String> subjects;

    public Course(String courseName, ProgramType program) {

        this.courseName = courseName;
        this.program = program;
        this.subjects = new ArrayList<>();
    }

    // Overloaded method
    public void addSubject(String subject) {

        subjects.add(subject);
    }

    public void addSubject(String subject1, String subject2) {

        subjects.add(subject1);
        subjects.add(subject2);
    }

    public void displayCourse() {

        System.out.println("\nProgram: " + courseName);
        System.out.println("Subjects:");

        for (String subject : subjects) {
            System.out.println("  - " + subject);
        }
    }
}