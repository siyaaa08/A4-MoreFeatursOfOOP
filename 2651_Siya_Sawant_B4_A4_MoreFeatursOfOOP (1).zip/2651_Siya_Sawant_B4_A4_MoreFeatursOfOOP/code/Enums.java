enum MemberType {
    STUDENT,
    TEACHING_STAFF,
    NON_TEACHING_STAFF
}

enum ActivityType {
    ACADEMIC,
    NON_ACADEMIC
}

enum ProgramType {
    BCA,
    MCA,
    MSC_AI,
    MSC_DATA_SCIENCE
}