public class GenericUtility {

    public static <T> void printItem(T item) {

        System.out.println("Generic item: " + item);
    }
}