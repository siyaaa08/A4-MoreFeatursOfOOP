interface Reportable {
    void generateReport();
}

interface Payable {
    void displaySalaryDetails();
}

interface Participatable {
    void participate(String activity);
}

// Multiple interface inheritance
interface AdvancedReportable extends Reportable, Payable {
    void advancedReport();
}