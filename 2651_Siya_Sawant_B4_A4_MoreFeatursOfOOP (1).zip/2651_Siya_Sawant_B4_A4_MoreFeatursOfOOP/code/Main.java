import java.io.*;
import java.util.*;

public class Main {

    public static void main(String[] args) {

        System.out.println(
                "==============================================");

        System.out.println(
                " DCST - NIRF OOP CASE STUDY");

        System.out.println(
                " Goa University");

        System.out.println(
                "==============================================");

        // ==========================================
        // 1. OBJECT REFERENCING & CONSTRUCTORS
        // ==========================================

        System.out.println(
                "\n===== 1. OBJECT REFERENCING & CONSTRUCTORS =====");

        Address address =
                new Address("Panjim");

        Student s1 =
                new Student(
                        "Siya",
                        21,
                        "CST",
                        "Goa University",
                        "ST001",
                        ProgramType.BCA,
                        8.5,
                        address
                );

        Student s2 = s1;

        System.out.println(
                "Original student name: " + s1.getName());

        s2.setName("Siya Sawant");

        System.out.println(
                "After modifying s2:");
        System.out.println(
                "s1 name = " + s1.getName());
        System.out.println(
                "s2 name = " + s2.getName());

        System.out.println(
                "Both references point to the same object.");

        // ==========================================
        // 2. STATIC ATTRIBUTES, METHODS & ENUMS
        // ==========================================

        System.out.println(
                "\n===== 2. STATIC ATTRIBUTES, METHODS & ENUMS =====");

        TeachingStaff teacher =
                new TeachingStaff(
                        "Dr. Anita",
                        40,
                        "CST",
                        "Goa University",
                        "Assistant Professor",
                        65000
                );

        NonTeachingStaff staff =
                new NonTeachingStaff(
                        "Ramesh",
                        38,
                        "CST",
                        "Goa University",
                        "Lab Assistant",
                        35000
                );

        Person.displayMemberCount();

        System.out.println(
                "Enum Program Type: " + ProgramType.BCA);

        // ==========================================
        // 3. MULTIPLE INHERITANCE
        // ==========================================

        System.out.println(
                "\n===== 3. MULTIPLE INHERITANCE =====");

        System.out.println(
                "Java does NOT support multiple class inheritance.");

        System.out.println(
                "Example of invalid syntax:");

        System.out.println(
                "class C extends A, B   // Not allowed");

        System.out.println(
                "\nJava supports multiple interface implementation.");

        teacher.generateReport();
        teacher.displaySalaryDetails();

        System.out.println(
                "\nTeachingStaff extends Person and implements:");
        System.out.println(
                "Reportable + Payable");

        // ==========================================
        // 4. ACCESS MODIFIERS
        // ==========================================

        System.out.println(
                "\n===== 4. ACCESS MODIFIERS =====");

        AccessDemo access =
                new AccessDemo();

        System.out.println(
                "Public: " + access.publicData);

        System.out.println(
                "Private through getter: "
                        + access.getPrivateData());

        System.out.println(
                "Protected: "
                        + access.protectedData);

        access.displayInsideClass();

        // ==========================================
        // 5. ABSTRACT CLASS & INTERFACE
        // ==========================================

        System.out.println(
                "\n===== 5. ABSTRACT CLASS & INTERFACE =====");

        Person p1 = s1;
        Person p2 = teacher;
        Person p3 = staff;

        p1.displayDetails();

        System.out.println();

        p2.displayDetails();

        System.out.println();

        p3.displayDetails();

        // ==========================================
        // 6. CLASS AS TYPE & MESSAGE PASSING
        // ==========================================

        System.out.println(
                "\n===== 6. CLASS AS TYPE & MESSAGE PASSING =====");

        MessagePassing.sendForReport(s1);

        MessagePassing.sendForReport(teacher);

        MessagePassing.sendForReport(staff);

        // ==========================================
        // 7. POLYMORPHISM
        // ==========================================

        System.out.println(
                "\n===== 7. POLYMORPHISM =====");

        System.out.println(
                "--- Method Overriding ---");

        Person poly = s1;

        poly.displayDetails();

        System.out.println(
                "\n--- Method Overloading ---");

        s1.registerActivity("InfoFest");

        s1.registerActivity(
                "InfoFest",
                2026);

        // ==========================================
        // 8. GENERICS & COLLECTIONS
        // ==========================================

        System.out.println(
                "\n===== 8. GENERICS & COLLECTIONS =====");

        // List
        List<String> activities =
                new ArrayList<>();

        activities.add("ISA");
        activities.add("Midpoint Examination");
        activities.add("SEA");
        activities.add("Study Tour");

        System.out.println("\nList:");

        for (String a : activities) {
            System.out.println("- " + a);
        }

        // Queue
        Queue<String> placementQueue =
                new LinkedList<>();

        placementQueue.add("Placement Training");
        placementQueue.add("Campus Recruitment");
        placementQueue.add("Mock Interview");

        System.out.println("\nQueue:");

        while (!placementQueue.isEmpty()) {
            System.out.println(
                    "- " + placementQueue.poll());
        }

        // Set
        Set<String> departments =
                new HashSet<>();

        departments.add("CST");
        departments.add("CST");
        departments.add("Management");

        System.out.println(
                "\nSet: " + departments);

        // Map
        Map<String, Integer> students =
                new HashMap<>();

        students.put("BCA", 120);
        students.put("MCA", 80);
        students.put("MSc AI", 50);
        students.put("MSc Data Science", 45);

        System.out.println(
                "\nMap: " + students);

        // Generic class
        Repository<String> repository =
                new Repository<>();

        repository.add("Student Record");
        repository.add("Staff Record");
        repository.add("Course Record");

        System.out.println("\nGeneric Repository:");

        repository.display();

        // Generic function
        GenericUtility.printItem("NIRF Data");
        GenericUtility.printItem(2026);

        // ==========================================
        // 9. EXCEPTION HANDLING
        // ==========================================

        System.out.println(
                "\n===== 9. EXCEPTION HANDLING =====");

        try {

            s1.validateCGPA();

            int result = 10 / 0;

            System.out.println(result);

        } catch (InvalidStudentException e) {

            System.out.println(
                    "Custom Exception: "
                            + e.getMessage());

        } catch (ArithmeticException e) {

            System.out.println(
                    "Runtime Error: Cannot divide by zero.");

        } finally {

            System.out.println(
                    "Finally block executed.");
        }

        // Throwing exception
        try {

            Student invalidStudent =
                    new Student(
                            "Test Student",
                            20,
                            "CST",
                            "Goa University",
                            "ST999",
                            ProgramType.BCA,
                            12.0,
                            new Address("Goa")
                    );

            invalidStudent.validateCGPA();

        } catch (InvalidStudentException e) {

            System.out.println(
                    "Thrown Custom Exception: "
                            + e.getMessage());
        }

        // ==========================================
        // 10. REFLECTION
        // ==========================================

        System.out.println(
                "\n===== 10. REFLECTION =====");

        Class<?> studentClass =
                Student.class;

        System.out.println(
                "Class name: "
                        + studentClass.getName());

        System.out.println(
                "Declared fields:");

        for (var field :
                studentClass.getDeclaredFields()) {

            System.out.println(
                    "- " + field.getName());
        }

        System.out.println(
                "Declared methods:");

        for (var method :
                studentClass.getDeclaredMethods()) {

            System.out.println(
                    "- " + method.getName());
        }

        // ==========================================
        // PERSISTENCE & FILE I/O
        // ==========================================

        System.out.println(
                "\n===== PERSISTENCE & FILE I/O =====");

        try {

            // File writing
            FileWriter writer =
                    new FileWriter(
                            "../output/student_data.txt");

            writer.write(
                    "Student Name: "
                            + s1.getName()
                            + "\nStudent ID: ST001"
                            + "\nProgram: BCA"
                            + "\nCGPA: 8.5");

            writer.close();

            System.out.println(
                    "Data written to student_data.txt");

            // File reading
            BufferedReader reader =
                    new BufferedReader(
                            new FileReader(
                                    "../output/student_data.txt"));

            String line;

            System.out.println(
                    "\nReading file:");

            while ((line = reader.readLine()) != null) {

                System.out.println(line);
            }

            reader.close();

            // Serialization
            ObjectOutputStream output =
                    new ObjectOutputStream(
                            new FileOutputStream(
                                    "../output/student.ser"));

            output.writeObject(s1);

            output.close();

            System.out.println(
                    "\nStudent object serialized.");

            // Deserialization
            ObjectInputStream input =
                    new ObjectInputStream(
                            new FileInputStream(
                                    "../output/student.ser"));

            Student restored =
                    (Student) input.readObject();

            input.close();

            System.out.println(
                    "Student object deserialized.");

            System.out.println(
                    "Restored student: "
                            + restored.getName());

        } catch (IOException |
                 ClassNotFoundException e) {

            System.out.println(
                    "I/O Error: "
                            + e.getMessage());
        }

        // ==========================================
        // CLONING
        // ==========================================

        CloneDemo.run(s1);

        // ==========================================
        // ACADEMIC ACTIVITIES
        // ==========================================

        System.out.println(
                "\n==============================================");

        System.out.println(
                "ACADEMIC ACTIVITIES");

        System.out.println(
                "==============================================");

        Activity[] academicActivities = {

                new Activity(
                        "ISA",
                        "Internal Semester Assessment",
                        ActivityType.ACADEMIC,
                        2026),

                new Activity(
                        "Midpoint Examination",
                        "Mid-semester academic evaluation",
                        ActivityType.ACADEMIC,
                        2026),

                new Activity(
                        "SEA",
                        "Semester End Assessment",
                        ActivityType.ACADEMIC,
                        2026),

                new Activity(
                        "Study Tour",
                        "Educational industrial and academic visit",
                        ActivityType.ACADEMIC,
                        2026),

                new Activity(
                        "Placement Training",
                        "Training for placement and recruitment",
                        ActivityType.ACADEMIC,
                        2026),

                new Activity(
                        "Project Presentation",
                        "Academic project presentation",
                        ActivityType.ACADEMIC,
                        2026),

                new Activity(
                        "Seminars",
                        "Academic seminars and knowledge sharing",
                        ActivityType.ACADEMIC,
                        2026),

                new Activity(
                        "Workshops",
                        "Technical and skill development workshops",
                        ActivityType.ACADEMIC,
                        2026),

                new Activity(
                        "Guest Lectures",
                        "Expert lectures and industry interaction",
                        ActivityType.ACADEMIC,
                        2026),

                new Activity(
                        "Internships",
                        "Industry-based practical learning",
                        ActivityType.ACADEMIC,
                        2026)
        };

        for (Activity activity :
                academicActivities) {

            activity.display();
        }

        // ==========================================
        // NON-ACADEMIC ACTIVITIES
        // ==========================================

        System.out.println(
                "\n==============================================");

        System.out.println(
                "NON-ACADEMIC ACTIVITIES");

        System.out.println(
                "==============================================");

        Activity[] nonAcademicActivities = {

                new Activity(
                        "InfoFest",
                        "Technical and cultural student festival",
                        ActivityType.NON_ACADEMIC,
                        2026),

                new Activity(
                        "Plateaunia",
                        "Student cultural and social event",
                        ActivityType.NON_ACADEMIC,
                        2026),

                new Activity(
                        "Play-on",
                        "Sports and recreational activities",
                        ActivityType.NON_ACADEMIC,
                        2026),

                new Activity(
                        "Cultural Events",
                        "Cultural and artistic activities",
                        ActivityType.NON_ACADEMIC,
                        2026),

                new Activity(
                        "Sports Activities",
                        "Indoor and outdoor sports",
                        ActivityType.NON_ACADEMIC,
                        2026),

                new Activity(
                        "Student Clubs",
                        "Student interest and technical clubs",
                        ActivityType.NON_ACADEMIC,
                        2026),

                new Activity(
                        "Social Outreach",
                        "Community and social service activities",
                        ActivityType.NON_ACADEMIC,
                        2026),

                new Activity(
                        "Annual Day",
                        "Annual student and institutional celebration",
                        ActivityType.NON_ACADEMIC,
                        2026)
        };

        for (Activity activity :
                nonAcademicActivities) {

            activity.display();
        }

        // ==========================================
        // PROGRAMS AND COURSES
        // ==========================================

        System.out.println(
                "\n==============================================");

        System.out.println(
                "PROGRAMS & COURSES / SUBJECTS");

        System.out.println(
                "==============================================");

        Course bca =
                new Course(
                        "Bachelor of Computer Applications (BCA)",
                        ProgramType.BCA);

        bca.addSubject("Object Oriented Programming");
        bca.addSubject("Data Structures");
        bca.addSubject("Database Management Systems");
        bca.addSubject("Computer Networks");
        bca.addSubject("Operating Systems");
        bca.addSubject("Software Engineering");
        bca.addSubject("Web Development");
        bca.addSubject("Computer Architecture");

        bca.displayCourse();

        Course mca =
                new Course(
                        "Master of Computer Applications (MCA)",
                        ProgramType.MCA);

        mca.addSubject("Advanced Java");
        mca.addSubject("Advanced Data Structures");
        mca.addSubject("Software Engineering");
        mca.addSubject("Artificial Intelligence");
        mca.addSubject("Machine Learning");
        mca.addSubject("Cloud Computing");

        mca.displayCourse();

        Course ai =
                new Course(
                        "M.Sc. Artificial Intelligence",
                        ProgramType.MSC_AI);

        ai.addSubject("Artificial Intelligence");
        ai.addSubject("Machine Learning");
        ai.addSubject("Deep Learning");
        ai.addSubject("Natural Language Processing");
        ai.addSubject("Computer Vision");

        ai.displayCourse();

        Course dataScience =
                new Course(
                        "M.Sc. Data Science",
                        ProgramType.MSC_DATA_SCIENCE);

        dataScience.addSubject("Statistics");
        dataScience.addSubject("Python for Data Science");
        dataScience.addSubject("Data Visualization");
        dataScience.addSubject("Machine Learning");
        dataScience.addSubject("Big Data Analytics");

        dataScience.displayCourse();

        // ==========================================
        // FINAL
        // ==========================================

        System.out.println(
                "\n==============================================");

        System.out.println(
                "NIRF DATA PREPARATION COMPLETED");

        System.out.println(
                "==============================================");
    }
}