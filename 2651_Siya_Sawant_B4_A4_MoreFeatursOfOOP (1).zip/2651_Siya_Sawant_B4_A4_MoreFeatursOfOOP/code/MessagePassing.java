public class MessagePassing {

    public static void sendForReport(Reportable object) {

        System.out.println(
                "Message passed to generate report:");

        object.generateReport();
    }
}