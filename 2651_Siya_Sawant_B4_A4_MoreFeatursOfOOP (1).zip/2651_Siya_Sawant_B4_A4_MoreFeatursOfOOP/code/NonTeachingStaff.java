public class NonTeachingStaff extends Person
        implements Reportable, Payable {

    private String role;
    private double salary;

    public NonTeachingStaff(String name, int age,
                            String department,
                            String college,
                            String role,
                            double salary) {

        super(name, age, department, college);

        this.role = role;
        this.salary = salary;
    }

    @Override
    public void displayDetails() {

        System.out.println("Non-Teaching Staff : " + getName());
        System.out.println("Role                : " + role);
        System.out.println("Department          : " + department);
        System.out.println("Salary              : " + salary);
    }

    @Override
    public void generateReport() {

        System.out.println(
                "Non-teaching staff report generated for "
                        + getName());
    }

    @Override
    public void displaySalaryDetails() {

        System.out.println(
                "Salary of " + getName() + ": ₹" + salary);
    }
}