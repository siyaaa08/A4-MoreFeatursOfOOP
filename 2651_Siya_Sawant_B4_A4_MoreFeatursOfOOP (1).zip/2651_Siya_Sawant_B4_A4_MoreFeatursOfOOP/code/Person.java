import java.io.Serializable;

public abstract class Person implements Serializable, Cloneable {

    private String name;
    private int age;

    protected String department;

    public String college;

    protected static int memberCount = 0;

    // Constructor
    public Person(String name, int age, String department, String college) {
        this.name = name;
        this.age = age;
        this.department = department;
        this.college = college;
        memberCount++;
    }

    // Getters
    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    // Setter
    public void setName(String name) {
        this.name = name;
    }

    // Abstract method
    public abstract void displayDetails();

    // Static method
    public static void displayMemberCount() {
        System.out.println("Total members created: " + memberCount);
    }

    // Protected method
    protected void showDepartment() {
        System.out.println("Department: " + department);
    }

    // Shallow cloning
    @Override
    public Person clone() {
        try {
            return (Person) super.clone();
        } catch (CloneNotSupportedException e) {
            throw new RuntimeException(e);
        }
    }
}