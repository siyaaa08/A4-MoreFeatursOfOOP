import java.util.ArrayList;
import java.util.List;

public class Repository<T> {

    private List<T> items = new ArrayList<>();

    public void add(T item) {
        items.add(item);
    }

    public List<T> getItems() {
        return items;
    }

    public void display() {

        for (T item : items) {
            System.out.println(item);
        }
    }
}