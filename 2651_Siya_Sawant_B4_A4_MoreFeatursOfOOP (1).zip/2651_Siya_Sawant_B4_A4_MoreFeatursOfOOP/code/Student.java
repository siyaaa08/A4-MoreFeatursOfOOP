public class Student extends Person
        implements Reportable, Participatable {

    private String studentId;
    private ProgramType program;
    private double cgpa;

    public Address address;

    // Constructor
    public Student(String name, int age, String department,
                   String college, String studentId,
                   ProgramType program, double cgpa,
                   Address address) {

        super(name, age, department, college);

        this.studentId = studentId;
        this.program = program;
        this.cgpa = cgpa;
        this.address = address;
    }

    @Override
    public void displayDetails() {

        System.out.println("Student Name : " + getName());
        System.out.println("Student ID   : " + studentId);
        System.out.println("Program      : " + program);
        System.out.println("CGPA         : " + cgpa);
        System.out.println("Department   : " + department);
        System.out.println("College      : " + college);
    }

    // Overriding
    @Override
    public void generateReport() {

        System.out.println(
                "Student academic report generated for " + getName());
    }

    @Override
    public void participate(String activity) {

        System.out.println(
                getName() + " participated in " + activity);
    }

    // Overloading
    public void registerActivity(String activity) {

        System.out.println(
                "Registered for: " + activity);
    }

    public void registerActivity(String activity, int year) {

        System.out.println(
                "Registered for: " + activity +
                " (" + year + ")");
    }

    // Custom exception
    public void validateCGPA() throws InvalidStudentException {

        if (cgpa < 0 || cgpa > 10) {
            throw new InvalidStudentException(
                    "Invalid CGPA. CGPA must be between 0 and 10.");
        }

        System.out.println("CGPA is valid.");
    }

    // Deep clone
    public Student deepClone() {

        Address newAddress =
                new Address(this.address.city);

        return new Student(
                getName(),
                getAge(),
                department,
                college,
                studentId,
                program,
                cgpa,
                newAddress
        );
    }
}