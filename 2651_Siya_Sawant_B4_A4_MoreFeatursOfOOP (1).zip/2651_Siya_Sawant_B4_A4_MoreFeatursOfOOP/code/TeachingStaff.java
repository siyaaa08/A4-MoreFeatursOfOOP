public class TeachingStaff extends Person
        implements Reportable, Payable {

    private String designation;
    private double salary;

    public TeachingStaff(String name, int age,
                         String department,
                         String college,
                         String designation,
                         double salary) {

        super(name, age, department, college);

        this.designation = designation;
        this.salary = salary;
    }

    @Override
    public void displayDetails() {

        System.out.println("Teaching Staff : " + getName());
        System.out.println("Designation     : " + designation);
        System.out.println("Department      : " + department);
        System.out.println("Salary          : " + salary);
    }

    @Override
    public void generateReport() {

        System.out.println(
                "Teaching staff report generated for " + getName());
    }

    @Override
    public void displaySalaryDetails() {

        System.out.println(
                "Salary of " + getName() + ": ₹" + salary);
    }
}