program_run.txt contains the captured console output from running java Main.
program_output_*.png are readable terminal-style captures of that same output.
student_data.txt is created here if the program's file I/O path succeeds in this environment.
